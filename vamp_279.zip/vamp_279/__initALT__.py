bl_info = {
    "name": "vamp_279",
    "author": "Chris Allen", 
    "version": (1, 0, 0),
    "blender": (2, 79, 0),
    "location": "View3D",
    "description": "VAMP: Vector Art Motion Processor. Removes back faces.",
    "warning": "Requires one object group and one camera",
    "category": "Development",
}

# GOOD TUT: https://blender.stackexchange.com/questions/57306/how-to-create-a-custom-ui

import bpy
from bpy.props import IntProperty, EnumProperty, FloatProperty, BoolProperty, StringProperty, PointerProperty
from bpy.types import PropertyGroup, Operator, Panel, Scene
import bmesh
import mathutils
from mathutils import Vector, geometry, Matrix
from bpy_extras.object_utils import world_to_camera_view
from math import radians
import time
import random
import numpy as np#for triangle poly area

global sens # sensitivity - drives bracket vertex distance
global ray_dist # raycast distance
global cast_sens # raycast sensitivity, allows for offset of source vertex
global vert_limit # function slows exponentially for large vert counts. keep < 10k
global cam_x_scale
global cam_y_scale
global cam
global edge_sub_unit
global vamp_on 
global sil_mode
global collapse_angle

class VampProperties(PropertyGroup):
    vamp_target = StringProperty(
        name = "VAMP Target",
        description = "Active group for VAMP",
        default = "VisibleObjects"
    )
    vamp_sil_mode = BoolProperty(
        name = "Individual Silhouette Mode",
        default = False
    )
    vamp_cast_sensitivity = FloatProperty(
        name="Hit Test Offset",
        min = 0.00,
        max = 0.5,
        default = 0.02,
        precision = 3
    )
    vamp_edge_subdiv = FloatProperty(
        name = "Subdivision unit",
        min = 0.05,
        max = 2.0,
        default = 0.2
        # unit length of edge subdivisions, for simple_slice mode
    )
    vamp_raycast_dist = IntProperty(
        name = "Raycast Distance",
        min = 1,
        max = 100,
        description = "Hit testing distance",
        default = 10
    )
    vamp_crop = BoolProperty(
        name = "Crop to Camera",
        default = True,
        description = "Limit to camera frame"
    )
    vamp_scale = FloatProperty(
        name = "Output Scale",
        min = .25,
        max = 5,
        default = 1.0,
        description = "Resize final output",
    )
    vamp_denoise_pass = BoolProperty(
        name = "Denoise Pass",
        default = False 
    )
    vamp_denoise_thresh = FloatProperty(
        name = "Denoise Threshold",
        default = .05,
        min = .02,
        max = 10
    )    
    
# fixed parameters
vamp_on = False #switched off at beginning
vert_limit = 100000 #keep below 100k for reasonable performance. 
collapse_angle = 1.5 # radians, for dissolve function.
#collapse_angle = 0 # radians, for dissolve function.

cam_x_scale = 4 #horiz aspect of camera.
cam_y_scale = 3 #horiz aspect of camera.

def item_check():
    global cam
    global scene
    scene = bpy.data.scenes[0]
    #print('--- running item check ---')
    target_name = bpy.context.scene.vamp_params.vamp_target
    if bpy.data.groups.get(target_name) is not None:
        #print('target group is there')        
        if len(bpy.data.groups[target_name].objects) > 0:
            #print('at least one object is there')
            #would be nice to check that these are all meshes also...
            if scene.camera is not None:
                cam = scene.camera
                #print('Camera is there')
                return True
            else:
                return False
        else:
            return False
    else:
        return False
    
def clean_up_first():
    global empty_mesh
    global scene
    target_name = bpy.context.scene.vamp_params.vamp_target
    
    #now, create new empty objects 
    empty_mesh = bpy.data.meshes.new('empty_mesh') 
    scene = bpy.context.scene
    if bpy.data.objects.get('_slicedFinal') is None:
        bpy.data.groups[target_name].objects[0].select = True
        newobj = bpy.data.objects.new(name='_slicedFinal',object_data = empty_mesh.copy())
        scene.objects.link(newobj)
    if bpy.data.objects.get('_silhouetteFinal') is None:
        bpy.data.groups[target_name].objects[0].select = True
        newobj = bpy.data.objects.new(name='_silhouetteFinal',object_data = empty_mesh.copy())
        scene.objects.link(newobj)   
    if bpy.data.objects.get('_flatSliced') is None:
        bpy.data.groups[target_name].objects[0].select = True
        newobj = bpy.data.objects.new(name='_flatSliced',object_data = empty_mesh.copy())
        scene.objects.link(newobj)  
    if bpy.data.objects.get('_flatSilhouette') is None:
        bpy.data.groups[target_name].objects[0].select = True
        newobj = bpy.data.objects.new(name='_flatSilhouette',object_data = empty_mesh.copy())
        scene.objects.link(newobj)          
    return {'FINISHED'}

    
def join_bmeshes(bmesh_list):
    # combine multiple meshes into a single mesh
    joined_bmesh = bmesh.new() 
    for bm in bmesh_list:
        temp_mesh = bpy.data.meshes.new(name='temp_mesh')
        bm.to_mesh(temp_mesh)
        joined_bmesh.from_mesh(temp_mesh) # appends transformed data to the bmesh        
    # returns bmesh
    return joined_bmesh


def get_all_the_stuff():
    global bm_all
    global original_vert_count
    target_name = bpy.context.scene.vamp_params.vamp_target

    #print('## running get_all_the_stuff')    
    bm_all = bmesh.new()       
    for obj in bpy.data.groups[target_name].objects:
        # evaluate object, which applies all modifiers
        # 2.79 alt version:
        data_copy = obj.to_mesh(scene,apply_modifiers=True,settings='PREVIEW')
        # also need to transform origin mesh, else they'll all be at 0,0,0
        the_matrix = obj.matrix_world        
        data_copy.transform(the_matrix) # transform mesh using source object transforms
        bm_all.from_mesh(data_copy) # appends transformed data to the bmesh
    original_vert_count=(len(data_copy.edges)) # test for vert count. if too high, just quit.
    # bm_all now contains bmesh containing all data we need for next step
    # we will also use it later for BVHTree hit testing     
    # output the mesh into real space. Not necessary for calcs.
    #output_object_fm_bmesh('_all',bm_all)
    #print('bm_all is ',bm_all
    return {'FINISHED'}

def get_sep_meshes():
    # iterate the original list, generate a LIST of individual meshes for further analysis
    global sep_meshes
    target_name = bpy.context.scene.vamp_params.vamp_target
    sep_meshes = []  
    bm_all = bmesh.new()       
    for obj in bpy.data.groups[target_name].objects:
        bm_obj = bmesh.new()               
        # evaluate object, which applies all modifiers
        # 2.79 alt version:
        data_copy = obj.to_mesh(scene,apply_modifiers=True,settings='PREVIEW')
        # also need to transform origin mesh, else they'll all be at 0,0,0
        the_matrix = obj.matrix_world        
        data_copy.transform(the_matrix) # transform mesh using source object transforms
        bm_obj.from_mesh(data_copy) # appends transformed data to the bmesh
        sep_meshes.append(bm_obj)
    # sep_meshes now contains multiple bmeshes, one each for original objects.
    return {'FINISHED'}    

def get_front(test_bmesh):
    global bm_front
    global cam_loc
    # transform to world (in case it's parented to something else
    # per https://blender.stackexchange.com/questions/39677/how-do-you-get-an-objects-position-and-rotation-through-script
    cam_loc = cam.matrix_world.to_translation()
    
    # take output from all_the_stuff, iterate faces vs camera and gen a new mesh
    # with only front faces
    bm_front = test_bmesh.copy()
    bm_front.normal_update()
    bm_front.verts.ensure_lookup_table()
    bm_front.edges.ensure_lookup_table()
    bm_front.faces.ensure_lookup_table()
    
    #first ID backfaces
    backfaces=[]
    for poly in bm_front.faces:
        pnorm = poly.normal
        cntr = poly.calc_center_median()
        vec = cntr - cam_loc
        norm_norm = pnorm.normalized()
        vec_norm = vec.normalized()
        dot_prod = vec_norm.dot(norm_norm)
        if dot_prod>0:
            backfaces.append(poly)
    #now remove selected backfaces         
    bmesh.ops.delete(bm_front, geom = backfaces, context = 3) # upd for 2.79 
    #  at this point, bm_front still contains extraneous vertices (assoc. with removed backfaces,) but no matter. 
    #  edges are all that are used next step.
    return bm_front 

def rebuild_edge(the_verts,edge_pairs):
    global rebuild_thresh
    #print(the_verts)
    #print(edge_pairs)
    rebuild_thresh = 0.1
    #takes broken edges, rebuilds into minimum number of larger edges
    new_verts = []
    new_edge_pairs = []
    edge_builder = []
    edge_builder = edge_pairs[0] #preload first edge
    for i in range (1, len(edge_pairs)-1):
        the_pair = edge_pairs[i]
        if the_pair == edge_builder:
            break
        else:
            if the_pair[0] == edge_builder[1]:
                # picking up where other left off, now see if they're colinear     
                the_area = mathutils.geometry.area_tri(the_verts[the_pair[0]],the_verts[the_pair[1]],the_verts[edge_builder[0]])
                if the_area < rebuild_thresh:
                    #linear points.
                    edge_builder[1] = the_pair[1]
                else:
                    #segment is done. move to next.
                    new_edge_pairs.append(edge_builder)
                    edge_builder = the_pair
    new_verts = the_verts
    return(new_verts,new_edge_pairs)
    

def distance(loc0,loc1):
    return (loc0-loc1).length    

# hit test. bvh version is reliable
def hit_test_bvh(originV,targetV,the_bvh):
    cast_sens = bpy.context.scene.vamp_params.vamp_cast_sensitivity
    # hit test using bvh. Will sidestep requirement to create _ray object in real space  
    direction_vect = (targetV - originV) # this seems correct, but let's try reversae
    offset_vect = direction_vect * (cast_sens)
    new_origin = originV + offset_vect # test with no offset fails. needs a buffer.
    direction = (direction_vect).normalized()# raycast expects a normalized vect
    ray_dist = bpy.context.scene.vamp_params.vamp_raycast_dist
    (loc,norm,indx,dist) = the_bvh.ray_cast(new_origin,direction,ray_dist)
    crop_to_camera = bpy.context.scene.vamp_params.vamp_crop
    if loc is not None:
        return True # vert will be excluded, because it hit something.
    else:
        # if vert is a candidate, may also need to also check if in cam view
        if crop_to_camera is False: 
            # camera crop turned off, just return hit check false
            return False 
        else:          
            #need to also test whether vert is within camera frame
            scene = bpy.context.scene # sh/b redundant..
            co_ndc = world_to_camera_view(scene, cam, originV)
            if (co_ndc[0] >= 0) and (co_ndc[0] <= 1) and \
            (co_ndc[0] >= 0) and (co_ndc[0] <= 1):
                return False # vert within camera view
            else:
                return True # vert outside of camera view, treat like a hit.  

def get_slicestuff(bm_test, bm_mask):
    # inputs: bm_test, bm_mask
    # outputs: bm_slice, bm_sil
    global cam
    global collapse_angle
    global bm_slice
    global bm_sil
    edge_sub_unit = bpy.context.scene.vamp_params.vamp_edge_subdiv
    # transform to world (in case it's parented to something else
    # per https://blender.stackexchange.com/questions/39677/how-do-you-get-an-objects-position-and-rotation-through-script
    cam_loc = cam.matrix_world.to_translation()
    
    # grab copy of bm_test for slicing
    bm_slice = bm_test.copy()    
    bm_slice.normal_update()
    bm_slice.faces.ensure_lookup_table()
    bm_slice.edges.ensure_lookup_table()
    bm_slice.verts.ensure_lookup_table()    
   
    edge_list = bm_slice.edges

    cam_v0 = cam_loc #set as global earlier, includes matrix transform
    compare_edges = edge_list # make dup list for comparison later
    
    # this is only for bvh version. 
    the_bvh = mathutils.bvhtree.BVHTree.FromBMesh(bm_mask, epsilon = 0.0)
           
    the_edges=[] # all visible edges
    the_sil_edges=[] # silhouette only
    
    #iterate through all (test_edge) 
    for test_edge in edge_list:
		## BEGIN SIMPLE_SLICE HERE ##################
		# subdivide edges based on edge_sub_unit
		# create sequence of edges that subdivides this edge n times              
        clean_edg_verts = []
        broken_edg_verts = []
        test_vert0 = test_edge.verts[0].co
        test_vert1 = test_edge.verts[1].co 
        test_edge_length = distance(test_vert0,test_vert1) 
        
        if edge_sub_unit > test_edge_length:
            #just one segment
            clean_edg_verts.append(test_vert0)
            clean_edg_verts.append(test_vert1)
        else:
            #if length might be subdivided, do the math.       
            #if edge_sub_unit > 0:
            edge_sub_count = round(test_edge_length / edge_sub_unit)
            #else:
            if edge_sub_count < 1:
                edge_sub_count = 1
                clean_edg_verts.append(test_vert0)
                clean_edg_verts.append(test_vert1)
            else:                
                clean_edg_verts.append(test_vert0) # put in starting point for vertex seq        
                edge_sub_offset = (test_vert1 - test_vert0)/edge_sub_count
                for i in range(1, edge_sub_count-1):
                    new_vert = test_vert0 + (i * edge_sub_offset)
                    clean_edg_verts.append(new_vert)
                clean_edg_verts.append(test_vert1) # put in ending point for vertex seq
        ## END SIMPLE_SLICE HERE ##################   
        
        # generate new edge list from vertices above
        for x in range (0,len(clean_edg_verts)-1):
            start_vert = clean_edg_verts[x]
            end_vert = clean_edg_verts[x+1]
            edge_pair=[start_vert,end_vert]
            cam_v0 = cam_loc
            # do hit testing to confirm both ends of edge are visible
            # i.e. ray cast from point to camera doesn't hit anything                           
            # bvh raycasting follows
            # uses hit_test_bvh(originV,targetV,the_bvh)
            if hit_test_bvh(start_vert,cam_v0,the_bvh) is False and \
                hit_test_bvh(end_vert,cam_v0,the_bvh) is False:
                    the_edges.append(edge_pair)
                    # now test for silhouette:
                    if hit_test_bvh(start_vert,(start_vert+(start_vert-cam_v0)),the_bvh) is False and \
                        hit_test_bvh(end_vert,(end_vert+(end_vert-cam_v0)),the_bvh) is False:
                            the_sil_edges.append(edge_pair)                            
                        
    
    # now we've got final vertex pairs for edges, need to make a mesh of it.

    #first, make a set of unique vertices
    final_verts=[]
    for pairs in the_edges:
        vert1=pairs[0]
        if vert1 not in final_verts: 
            final_verts.append(vert1)
        vert2=pairs[1]
        if vert2 not in final_verts: 
            final_verts.append(vert2)
    
    #now iterate thru edge pairs the_edges, find vert indices from above
    final_edges=[]
    for pairs in the_edges:        
        vert0=pairs[0]
        vert_start=final_verts.index(vert0)
        vert1=pairs[1]
        vert_end=final_verts.index(vert1)       
        new_pair=[vert_start,vert_end]
        final_edges.append(new_pair)
        
    #repeating steps for silhouette: unique verts
    final_sil_verts=[]
    for pairs in the_sil_edges:
        vert1=pairs[0]
        if vert1 not in final_sil_verts: 
            final_sil_verts.append(vert1)
        vert2=pairs[1]
        if vert2 not in final_sil_verts: 
            final_sil_verts.append(vert2)
        
    final_sil_edges=[] #silhouette
    for pairs in the_sil_edges:        
        vert1=pairs[0]
        vert_start=final_sil_verts.index(vert1)
        vert2=pairs[1]
        vert_end=final_sil_verts.index(vert2)       
        new_pair=[vert_start,vert_end]
        final_sil_edges.append(new_pair)    

    final_faces=[] #empty list, for completeness
    
    # create new mesh, put mesh into _sliceFinal
    nu_slice_mesh = bpy.data.meshes.new(name='New Slice')
    
    #nu_slice_mesh.from_pydata(final_verts,final_edges,final_faces)  
    print('Final Verts is')
    print(final_verts[0])
    print('Final Edges is')
    print(final_edges)    
    
    #alt version using rebuild_edge
    (new_verts,new_edge_pairs) = rebuild_edge(final_verts,final_edges)
    nu_slice_mesh.from_pydata(new_verts,new_edge_pairs,final_faces)  

    
    #bm_slice = bmesh.new()
    #bm_slice.from_mesh(nu_slice_mesh)
    
    #the_verts = bm_slice.verts
    #the_edges = bm_slice.edges
    #(new_verts,new_edge_pairs) = rebuild_edge(final_verts,final_edges)
    #bm_slice.edges = new_edge_pairs        
    bmesh.ops.dissolve_verts(bm_slice,verts=bm_slice.verts)
    #bmesh.ops.dissolve_limit(bm_slice,angle_limit=0.182665)
    #the_edges=bm_slice.edges
    #the_edges = [e for e in bm_slice.edges]
    #bmesh.ops.dissolve_edges(bm_slice,edges=the_edges,use_verts=True)
    #bmesh.ops.dissolve_edges(bm_slice,edges=the_edges,use_verts=False)
    #bmesh.ops.dissolve_edges(bm_slice)
    #bmesh.ops.dissolve_limit(bm_slice)  
    #bmesh.ops.dissolve_edges(bm_slice,edges=the_edges)
    # bm_slice is now complete. Next steps create object from it.
    
    bm_slice.to_mesh(nu_slice_mesh)
    nu_slice_mesh.update()
    #bm.clear() 
    sl_obj = bpy.data.objects['_slicedFinal']
    sl_obj.data = nu_slice_mesh
    
    
    # create new silhouette mesh, put into _silhouetteFinal
    nu_sil_mesh = bpy.data.meshes.new(name='New Silhouette')
    nu_sil_mesh.from_pydata(final_sil_verts,final_sil_edges,final_faces)  #too many verts, but they get deduped by dissolve below  
    bm_sil = bmesh.new()
    bm_sil.from_mesh(nu_sil_mesh)
    #bmesh.ops.dissolve_limit(bm_sil, angle_limit=radians(collapse_angle), verts=bm_sil.verts, edges=bm_sil.edges)
    bmesh.ops.dissolve_limit(bm_sil)
    #bmesh.ops.dissolve_edges(bm_sil,use_verts=True)
    # bm_sil is now complete
    
    bm_sil.to_mesh(nu_sil_mesh)
    nu_sil_mesh.update()
    #bm.clear() 
    #bm.free()  
    sil_obj = bpy.data.objects['_silhouetteFinal']
    sil_obj.data = nu_sil_mesh

    return bm_slice, bm_sil  

def make_flatso(bm_output,flatso_name):
    #remap to flat plane for oscistudio to see
    global cam
    global vamp_scale
    vamp_scale = bpy.context.scene.vamp_params.vamp_scale
    # determine location based on xy cam scale
    #flat_loc = Vector((0,0,0))
    flat_loc = Vector ((-0.5 * cam_x_scale * vamp_scale,-0.5 * cam_y_scale * vamp_scale,0))
    # first, make flatSliced    
    flat_sliced = bpy.data.objects[flatso_name]
    mat_world = flat_sliced.matrix_world
    
    # use bm_output, remap vertices
    FlatVerts = []    
    for v in bm_output.verts:
        #co_ndc = world_to_camera_view(scene, cam, mat_world * v.co)
        co_ndc = world_to_camera_view(scene, cam, v.co)
        
        v.co.x = co_ndc[0] * cam_x_scale * vamp_scale
        v.co.y = co_ndc[1] * cam_y_scale * vamp_scale
        v.co.z = 0
    bm_output.to_mesh(flat_sliced.data)
    flat_sliced.location = flat_loc 
    scene.update()
    #bm_output.free()    
    return {'FINISHED'}

def main_routine(): 
    global cam
    global sil_mode

    start_time=time.time()   
    print('--- running main routine ---')
    # presumes item_check run first, to ensure data is there.
    #print('main routine now.')
    clean_up_first()
    get_all_the_stuff()
    print('original vert count is: ',original_vert_count)    
    if original_vert_count < vert_limit:    
        # testing area

        #both of these act on all objects in Group 
        #get_all_the_stuff()
        #print('bm_all is ',bm_all)
        get_sep_meshes()
        #print('sep_meshes is ',sep_meshes)

        sil_meshes = []
		# STRANGE: why am I running getslicestuff on these meshes? why not just join and move on?
		# answer: to yield SEPARATE silhouette files for each.
		# 1- visible faces, 
		# 2- overall silhouette (combines objects, then brings back silhouette)
		# 3- individual object silhouettes
		
		# sil_mode switch: 
		# False - faces, overall silhouette. Treats objects as one 
		# True - silhouettes, then individual objects
        
        sil_mode = bpy.context.scene.vamp_params.vamp_sil_mode # get from user toggle
#        sil_mode = context.scene.placeholder.vamp_sil_mode
        for bm_single in sep_meshes:
            sil = get_slicestuff(bm_single,bm_single)
            if sil_mode is False:
                sil_meshes.append(sil[0])
            else:
                sil_meshes.append(sil[1])

        joined = join_bmeshes(sil_meshes)

        # these act on any bmesh provided

        #joined = join_bmeshes(sep_meshes)
        #print('joined is ',joined)

        #front = get_front(joined)
        #print('front is ',front)

        (bm_slice, bm_sil) = get_slicestuff(joined, bm_all)
        scene.update()
        make_flatso(bm_slice,'_flatSliced')
        make_flatso(bm_sil,'_flatSilhouette')

    else:
        print('###########')
        print('I quit.  Vert limit is',vert_limit)
        print('This project is',original_vert_count,'verts, and would take too long.')        
        print('###########')            
    end_time=time.time()
    print('execution took ',end_time - start_time,' seconds.')
    print('original vert count was: ',original_vert_count)    
    return {'FINISHED'}

class OBJECT_OT_vamp_once(bpy.types.Operator):
    bl_label = "VAMP ONCE"
    bl_idname = "render.vamp_once"
    bl_description = "VAMP ONCE"       
    def execute(self, context):
        global cam
        if item_check():
            main_routine()
        else:
            print('item_check failed. :(  ')                   
        return {'FINISHED'}   
    
    

class OBJECT_OT_vamp_turn_on(bpy.types.Operator):
    bl_label = "Turn on VAMP"
    bl_idname = "render.vamp_turn_on"
    bl_description = "Turn on VAMP"        
    def execute(self, context):
        print("turning vamp on")
        global vamp_on
        scene = context.scene
        vampparams = scene.vamp_params
        print("Hello World")
        print("vamp_target: ", vampparams.vamp_target)

        vamp_on = True
        if item_check():
            main_routine()
        else:
            print('item_check failed. :(  ')  
            vamp_on = False                 
        return {'FINISHED'}

class OBJECT_OT_vamp_turn_off(bpy.types.Operator):
    bl_label = "Turn off VAMP"
    bl_idname = "render.vamp_turn_off"
    bl_description = "Turn off VAMP"        
    def execute(self, context):
        print("turning vamp off")
        global vamp_on
        vamp_on = False                 
        return {'FINISHED'}




class Vamp_PT_Panel(bpy.types.Panel):
    #Creates a Panel in the render context of the properties editor
    bl_label = "VAMP Settings"
    bl_idname = "VAMP_PT_layout"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "render"
    bl_options = {'DEFAULT_CLOSED'}
    
    
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        vampparams = scene.vamp_params
      
        #VAMP ON/OFF
        if vamp_on is True:
            row = layout.row()
            row.scale_y = 2.0
            row.operator("render.vamp_turn_off", text="Turn Off VAMP")
        else:   
            # Operator (below) must point to a legit operation, else button will not show.
            row = layout.row()
            row.scale_y = 2.0
            row.operator("render.vamp_turn_on", text="Turn On VAMP")

        
        #VAMP ONCE
        row = layout.row()
        row.scale_y = 1.5
        row.operator("render.vamp_once", text="VAMP ONCE")        
        layout.separator()
        # above.. works
        
        #user options
        layout.prop(vampparams, "vamp_sil_mode")
        layout.prop(vampparams, "vamp_crop")
        layout.prop(vampparams, "vamp_target")
        
        layout.prop(vampparams, "vamp_scale")
        layout.prop(vampparams, "vamp_edge_subdiv")
        layout.prop(vampparams, "vamp_raycast_dist")
        layout.prop(vampparams, "vamp_cast_sensitivity")
        
        layout.prop(vampparams, "vamp_denoise_pass")   
        layout.prop(vampparams, "vamp_denoise_thresh")         

classes = (OBJECT_OT_vamp_once,OBJECT_OT_vamp_turn_on,OBJECT_OT_vamp_turn_off,VampProperties,Vamp_PT_Panel)

def vamp_handler(scene):    
    global vamp_on
    global cam
    if vamp_on is True:
        if item_check():
            main_routine()
        else:
            print('item_check failed. :(  ')      

def register():
    bpy.app.handlers.frame_change_post.clear()
    bpy.app.handlers.frame_change_post.append(vamp_handler)
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.vamp_params = PointerProperty(type=VampProperties)   

 
def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)    
    del bpy.types.Scene.vamp_params   

if __name__ == "__main__":
   register()